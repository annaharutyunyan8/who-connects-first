# Who connects first?

An interactive explainer: two rules can order a grid connection queue — **by date** (first come, first served) or **by readiness** (first ready, first connected). The page runs both to the end and sets them against what Ofgem/NESO, FERC, the European Commission, CEER and the IEA have published.

Personal view of Anna Harutyunyan, Yerevan. Figures as of 26 October 2026; sources are linked on the page. The queue model is illustrative and is not a forecast for any country.

**Live page:** published with GitHub Pages from the `main` branch, root folder.
